"""Build the Riverside Blender stage and two portrait editorial timelines."""
import argparse
from collections import defaultdict
import itertools
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Vector

P=argparse.ArgumentParser(description=__doc__)
P.add_argument("town",type=Path)
P.add_argument("performance",type=Path)
P.add_argument("output",type=Path)
P.add_argument("--sample",action="store_true")
args=P.parse_args(sys.argv[sys.argv.index("--")+1:])
root=Path(__file__).resolve().parents[1]
media=root/"media"
town=json.loads(args.town.read_text())
performance=json.loads(args.performance.read_text())
timings=json.loads((media/"timings.json").read_text())

bpy.context.preferences.filepaths.save_version=0
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
base=bpy.context.scene
base.name="01 • Last Bus — Stage"
materials={}
cube_vertices=list(itertools.product((-.5,.5),repeat=3))
cube_faces=((0,1,3,2),(4,6,7,5),(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3))
all_meshes={}

def rgb(value):
    return tuple((min(255,max(0,float(v)))/255)**2.2 for v in value)

def material(name,color,rough=.56,metal=0,emission=0):
    if name in materials:return materials[name]
    m=bpy.data.materials.new(name)
    m.diffuse_color=(*rgb(color),1)
    m.use_nodes=True
    shader=m.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value=m.diffuse_color
    shader.inputs["Roughness"].default_value=rough
    shader.inputs["Metallic"].default_value=metal
    if "/ jacket" in name or "/ trouser" in name:
        texture=m.node_tree.nodes.new("ShaderNodeTexNoise")
        texture.inputs["Scale"].default_value=98
        texture.inputs["Detail"].default_value=2
        bump=m.node_tree.nodes.new("ShaderNodeBump")
        bump.inputs["Strength"].default_value=.18
        bump.inputs["Distance"].default_value=.022
        m.node_tree.links.new(texture.outputs["Fac"],bump.inputs["Height"])
        m.node_tree.links.new(bump.outputs["Normal"],shader.inputs["Normal"])
    if emission:
        shader.inputs["Emission Color"].default_value=m.diffuse_color
        shader.inputs["Emission Strength"].default_value=emission
    materials[name]=m
    return m

def V(p): return Vector((p[0],p[2],p[1]))

def collection(name,parent):
    c=bpy.data.collections.new(name)
    parent.children.link(c)
    return c

def mesh(name,vertices,poly):
    me=bpy.data.meshes.new(name)
    me.from_pydata(vertices,[],poly)
    me.update()
    return me

def object_(name,me,group,parent=None):
    obj=bpy.data.objects.new(name,me)
    group.objects.link(obj)
    if parent:obj.parent=parent
    return obj

def empty(name,group,parent=None,p=(0,0,0)):
    obj=object_(name,None,group,parent)
    obj.empty_display_size=.18
    obj.location=p
    return obj

def bevel(obj,width=.04,segments=2):
    mod=obj.modifiers.new("Rounded edges","BEVEL")
    mod.width,mod.segments=width,segments
    mod.affect="EDGES"
    normal=obj.modifiers.new("Weighted normals","WEIGHTED_NORMAL")
    normal.keep_sharp=True

def box(name,p,s,m,group,parent=None,edge=.035):
    me=mesh(name,[tuple(v[i]*s[i] for i in range(3)) for v in cube_vertices],cube_faces)
    me.materials.append(m)
    ob=object_(name,me,group,parent)
    ob.location=p
    if edge: bevel(ob,edge)
    return ob

def ball(name,p,s,m,group,parent=None):
    key=m.name
    if key not in all_meshes:
        coords=[(0,0,1)]
        for yi in range(1,8):
            phi=math.pi*yi/8
            coords.extend((math.sin(phi)*math.cos(x*math.pi/8),math.sin(phi)*math.sin(x*math.pi/8),math.cos(phi)) for x in range(16))
        coords.append((0,0,-1))
        faces=[(0,1+k,1+(k+1)%16) for k in range(16)]
        for row in range(6):
            off=1+16*row
            faces.extend((off+k,off+16+k,off+16+(k+1)%16,off+(k+1)%16) for k in range(16))
        last=1+16*6
        faces.extend((len(coords)-1,last+(k+1)%16,last+k) for k in range(16))
        me=mesh(name,coords,faces)
        me.materials.append(m)
        all_meshes[key]=me
        for face in me.polygons:face.use_smooth=True
    ob=object_(name,all_meshes[key],group,parent)
    ob.location=p
    ob.scale=s
    return ob

def font(name,text,p,size,m,group,parent=None,rotation=(math.pi/2,0,0)):
    curve=bpy.data.curves.new(name,"FONT")
    curve.body=text
    curve.size=size
    curve.align_x="CENTER"
    curve.align_y="CENTER"
    curve.extrude=.009
    curve.materials.append(m)
    ob=object_(name,curve,group,parent)
    ob.location=p
    ob.rotation_euler=rotation
    return ob

town_group=collection("RIVERSIDE • Shared world",base.collection)
town_batch=defaultdict(lambda:([],[]))
for index,row in enumerate(town["town"]):
    x,y,z,a,b,c,r,g,blue=map(float,row[:9])
    shape=row[9]
    color=tuple(int(v) for v in (r,g,blue))
    if shape=="Ball":
        ball("Tree canopy or town detail",V((x,y,z)),(a/2,c/2,b/2),material("Foliage / %s"%str(color),color,.74),town_group)
        continue
    # Keep the wide roadway smooth while preserving crisp detail around the storefronts.
    broad=max(a,b,c)>100
    key=(color,broad)
    verts,faces=town_batch[key]
    offset=len(verts)
    verts.extend((x+a*dx,z+c*dz,y+b*dy) for dx,dy,dz in cube_vertices)
    faces.extend(tuple(offset+k for k in reversed(face)) for face in cube_faces)
for (color,broad),(verts,faces) in town_batch.items():
    me=mesh("Street material",verts,faces)
    me.materials.append(material("Town / %s"%str(color),color,.64))
    ob=object_("Town surfaces",me,town_group)
    if not broad:bevel(ob,.026,2)

ivory=material("Ivory signage",(255,231,183))
ink=material("Deep ink",(26,30,42))
metal=material("Brushed bronze",(177,133,75),.38,.46)
glass=material("Transit blue glass",(98,155,169),.27,.15)
for title,x,y,z,size in [
    ("MORROW BAKERY",-23,6.16,-5.43,.69),("MARKET",-46,6.16,-6.43,.74),
    ("CORNER BOOKS",28,6.15,-5.92,.63),("BARBER",12,6.15,-5.87,.63),
    ("RIVERSIDE PARK",32,3.3,-1.71,.34),("RIVERSIDE HIGH",-29,6.15,10.06,.69),
    ("RIVER PARK • 02",25,4.55,-6.17,.38),("MARKET • 01",-42,4.55,-6.17,.4),
]:
    font(title,title,V((x,y,z)),size,ivory,town_group)

wardrobe={
 "Sister":((217,157,124),(187,63,92),(34,63,82),(54,25,26),(242,174,95),"MILO"),
 "Brother":((192,130,95),(50,157,166),(45,63,86),(35,23,32),(244,194,99),"27"),
 "Baker":((160,101,79),(226,175,103),(103,49,58),(54,30,30),(252,218,155),"MORROW"),
 "Driver":((144,98,83),(42,92,112),(42,57,70),(44,39,43),(243,193,88),"02"),
 "Local":((121,74,62),(119,151,107),(52,70,73),(35,27,24),(231,202,104),"R"),
 "Captain":((213,160,121),(95,93,178),(44,48,80),(61,33,28),(200,227,247),"04"),
 "Friend":((185,114,79),(73,129,99),(48,65,83),(42,29,27),(235,187,94),"11"),
 "NewKid":((148,92,71),(213,111,63),(42,75,101),(34,24,31),(239,214,151),"ELI"),
 "Spectator":((220,177,147),(70,138,174),(58,61,89),(67,42,28),(255,218,160),"09"),
}
shoe=material("Off-white sneaker sole",(241,226,196),.78)
eye_white=material("Warm sclera",(253,238,212))
iris=material("Amber iris",(102,60,46),.33)
blush=material("Warm cheek",(163,80,71))
moss=material("Mouth inner",(79,32,39))

class Rig:
    def __init__(self,name,group):
        skin_c,coat_c,trouser_c,hair_c,accent_c,number=wardrobe[name]
        skin=material(name+" / skin",skin_c,.62)
        coat=material(name+" / jacket",coat_c,.79)
        trouser=material(name+" / trouser",trouser_c,.75)
        hair=material(name+" / hair",hair_c,.52)
        accent=material(name+" / trim",accent_c,.68)
        self.root=empty(name+" / MOTION",group)
        self.chest=empty("Torso",group,self.root,p=(0,0,2.32))
        self.head=empty("Head / eyeline",group,self.chest,p=(0,0,1.45))
        self.scale=.81 if name=="Brother" else .93 if name=="NewKid" else 1
        self.root.scale=(self.scale,)*3
        box("Jacket",(.0,0,.44),(1.28,.75,1.27),coat,group,self.chest,.085)
        box("Collar",(0,-.389,.935),(.62,.07,.22),accent,group,self.chest,.043)
        box("Fitted hem",(0,0,-.175),(1.24,.76,.12),trouser,group,self.chest,.025)
        for sign in (-1,1):
            box("Chest stitch",(sign*.37,-.389,.345),(.038,.02,.61),accent,group,self.chest,.009)
        if name=="Baker":
            box("Canvas apron",(0,-.42,.18),(.87,.08,.8),accent,group,self.chest,.035)
            font("Embroidered apron mark",number,(0,-.475,.38),.14,ink,group,self.chest)
        elif name in {"Captain","Friend","NewKid","Spectator","Brother","Driver"}:
            box("Jersey patch",(.25,-.4,.54),(.36,.037,.25),accent,group,self.chest,.025)
            font("Jersey numerals",number,(.25,-.423,.54),.147,ink,group,self.chest)
        else:
            box("Chest pocket",(-.31,-.408,.43),(.31,.052,.245),accent,group,self.chest,.025)
            box("Zipper",(0,-.411,.4),(.033,.044,.73),metal,group,self.chest,.012)
        box("Neck",(0,0,1.13),(.32,.4,.32),skin,group,self.chest,.05)
        box("Head", (0,0,.15),(.98,.85,.91),skin,group,self.head,.15)
        for side in (-1,1):
            ball("Ear",(side*.485,-.005,.15),(.086,.12,.14),skin,group,self.head)
        ball("Hair back",(0,.188,.46),(.52,.34,.43),hair,group,self.head)
        styles={"Sister":(5,.15),"Brother":(4,.10),"Baker":(3,.08),"Driver":(4,.09),"Local":(6,.1),
            "Captain":(6,.135),"Friend":(4,.102),"NewKid":(7,.14),"Spectator":(3,.087)}
        count,bump=styles[name]
        for i in range(count):
            fr=i/max(1,count-1)
            x=(fr-.5)*.84
            ob=ball("Sculpted hair lock",(x,-.072-.19*math.sin(math.pi*fr),.60+math.sin(math.pi*fr)*bump),
                (.16+bump/4,.26+bump,.16+bump),hair,group,self.head)
            ob.rotation_euler.y=.37*(fr-.5)
        if name in {"Driver","Baker"}:
            box("Cap crown",(0,.06,.72),(.95,.68,.21),coat,group,self.head,.09)
            box("Cap visor",(0,-.39,.658),(.85,.48,.07),accent,group,self.head,.038)
        elif name in {"Sister","Captain"}:
            for side in (-1,1):
                ball("Hair side sweep",(side*.43,.04,.25),(.15,.35,.43),hair,group,self.head)
                ball("Stud earring",(side*.54,-.045,.085),(.04,.045,.043),accent,group,self.head)
        self.eyes=[]
        self.brows=[]
        for side in (-1,1):
            base=empty("Eye",group,self.head,(side*.215,-.426,.251))
            ball("Eye white",(0,-.013,0),(.108,.043,.081),eye_white,group,base)
            ball("Colored iris",(side*.009,-.047,0),(.059,.026,.065),iris,group,base)
            ball("Pupil",(side*.008,-.07,0),(.036,.018,.047),ink,group,base)
            ball("Catchlight",(-.016,-.085,.023),(.018,.01,.018),eye_white,group,base)
            self.eyes.append(base)
            self.brows.append(box("Eyebrow",(side*.216,-.464,.374),(.197,.042,.043),hair,group,self.head,.016))
            ball("Cheek",(side*.33,-.407,.082),(.077,.021,.044),blush,group,self.head)
        ball("Nose",(0,-.428,.153),(.073,.055,.065),skin,group,self.head)
        self.mouth=ball("Animated mouth",(0,-.442,-.095),(.103,.025,.026),moss,group,self.head)
        self.teeth=box("Smile glint",(0,-.466,-.083),(.118,.012,.022),eye_white,group,self.head,.007)
        self.arms=[]
        self.legs=[]
        self.hands={}
        for i,side in enumerate((-1,1)):
            label="Left" if side<0 else "Right"
            shoulder=empty(label+" shoulder",group,self.chest,(side*.77,0,.85))
            box("Sleeve",(0,0,-.297),(.396,.487,.648),coat,group,shoulder,.065)
            box("Sleeve edge",(0,0,-.581),(.411,.507,.12),accent,group,shoulder,.029)
            elbow=empty(label+" elbow",group,shoulder,(0,0,-.64))
            box("Forearm",(0,0,-.209),(.31,.37,.455),skin,group,elbow,.065)
            hand=empty(label+" hand grip",group,elbow,(0,-.092,-.508))
            box("Hand",(0,.064,.05),(.296,.36,.24),skin,group,hand,.062)
            self.hands[label+"Hand"]=hand
            self.arms.append((shoulder,elbow))
            hip=empty(label+" hip",group,self.root,(side*.321,0,2.15))
            box("Upper leg",(0,0,-.455),(.541,.55,1.01),trouser,group,hip,.06)
            knee=empty(label+" knee",group,hip,(0,0,-.998))
            box("Trouser leg",(0,0,-.44),(.51,.51,.97),trouser,group,knee,.055)
            box("Sneaker",(0,-.142,-1.012),(.55,.83,.27),coat,group,knee,.068)
            box("Sneaker sole",(0,-.183,-1.135),(.57,.847,.1),shoe,group,knee,.037)
            box("Laces",(0,-.283,-.901),(.28,.27,.037),accent,group,knee,.02)
            self.legs.append((hip,knee))
        self.joints=[self.root,self.chest,self.head,self.mouth,self.teeth,*self.eyes,*self.brows,*(o for pair in self.arms+self.legs for o in pair)]
        self.phase=0
        self.last=None

    def pose(self,state,seconds,previous_motion):
        if state is None:
            self.root.location=(0,0,-95)
            self.last=None
            return
        position,direction,values,kind,speed=state
        get=lambda key:values.get(key,0)
        self.root.location=V(position)
        if get("sit"):self.root.location.z-=.32
        self.root.rotation_euler.z=math.atan2(direction[0],-direction[2])
        if not previous_motion or self.last is None:
            self.phase=0
        if self.last is not None:
            self.phase+=(V(position)-self.last).length*math.tau/(2.85 if kind=="run" else 2.0)
        self.last=V(position)
        stride=math.sin(self.phase)*min(1,speed/2.8)
        bend=math.radians
        self.chest.rotation_euler=(bend(get("lean")+.9*math.sin(seconds*2.1)),0,bend(get("twist")))
        self.head.rotation_euler=(bend(get("pitch")-2*get("talk")*math.sin(seconds*15)),bend(get("roll")),bend(get("yaw")))
        for i,(hip,knee) in enumerate(self.legs):
            phase=(-1 if i==0 else 1)*stride
            hip.rotation_euler.x=bend(phase*(41 if kind=="run" else 27)-get("sit")*83)
            knee.rotation_euler.x=bend(max(0,phase)*(58 if kind=="run" else 31)+get("sit")*79)
        for i,(shoulder,elbow) in enumerate(self.arms):
            side=1 if i else -1
            raised=get("right" if i else "left")
            shoulder.rotation_euler=(bend(-raised+side*stride*29-9*get("talk")*math.sin(seconds*13)),
                bend(-side*(9+get("spread"))),0)
            elbow.rotation_euler.x=-bend(get("bend" if i else "leftBend")+max(0,-side*stride)*29)
        blink=max(0,1-abs((seconds+.18)%4.35-4.14)/.11)
        for eye in self.eyes:eye.scale.z=max(.08,1+.22*get("surprise")-.15*get("smile")-.9*blink)
        for i,brow in enumerate(self.brows):
            side=-1 if i==0 else 1
            brow.rotation_euler.y=bend(side*(24*get("anger")-15*get("worry")-13*get("sad")))
            brow.location.z=.374+.057*get("surprise")+.019*get("worry")
        self.mouth.scale.x=.103+.043*get("smile")
        self.mouth.scale.z=.025+.059*get("talk")*abs(math.sin(seconds*16))+.049*get("surprise")+.028*get("smile")
        self.teeth.scale=(1,1,.6+get("smile")) if get("smile")>.25 else (.001,.001,.001)

def world_matrix(obj):
    matrix=obj.matrix_basis.copy()
    while obj.parent:
        obj=obj.parent
        matrix=obj.matrix_basis@matrix
    return matrix

def world_position(obj):
    return world_matrix(obj).translation

def reach(rig,hand,point,weight):
    index=0 if hand=="LeftHand" else 1
    shoulder,elbow=rig.arms[index]
    palm=rig.hands[hand]
    origin=world_position(shoulder)
    current=world_position(palm)
    target=current.lerp(point,weight)
    direction=target-origin
    distance=direction.length
    if distance<.04:return
    axis=direction.normalized()
    upper,lower=.64*rig.scale,palm.location.length*rig.scale
    length=min(upper+lower-.008,max(abs(upper-lower)+.02,distance))
    offset=(upper*upper+length*length-lower*lower)/(2*length)
    flex=math.sqrt(max(0,upper*upper-offset*offset))
    pole=Vector((0,0,-1))-axis*axis.dot(Vector((0,0,-1)))
    if pole.length<.01:pole=Vector((1,0,0))-axis*axis.x
    corner=origin+axis*offset+pole.normalized()*flex
    reach_point=origin+axis*length
    for joint,endpoint,goal in ((shoulder,corner,Vector((0,0,-1))),(elbow,reach_point,palm.location)):
        basis=world_matrix(joint).to_quaternion()
        aim=(endpoint-world_position(joint)).normalized()
        delta=(basis@goal.normalized()).rotation_difference(aim)
        parent=world_matrix(joint.parent).to_quaternion()
        joint.rotation_euler=(parent.inverted()@delta@basis).to_euler("XYZ",joint.rotation_euler)


def create_props(group):
    result={key:empty(key.title()+" / motion",group) for key in ["bus","bag","cake","phone","ticket","ball","plug"]}
    p=result["bus"]
    teal=material("Transit / teal enamel",(39,124,128),.37,.18)
    window=material("Transit / untinted cabin glazing",(117,177,190),.21,.12)
    window.node_tree.nodes.get("Principled BSDF").inputs["Alpha"].default_value=.38
    window.surface_render_method="DITHERED"
    chrome=material("Transit / satin chrome",(167,181,184),.29,.75)
    tire=material("Transit / rubber",(35,37,46),.83)
    seat=material("Transit / upholstery",(101,81,104),.78)
    shine=material("Transit / headlight",(255,219,154),.26,0,.55)
    amber=material("Transit / indicator",(250,137,44),.28,0,1.3)
    box("Bus floor",(0,0,.93),(12.8,4.31,.68),teal,group,p,.15)
    box("Roof / ivory", (0,0,6.13),(12.8,4.41,.45),ivory,group,p,.18)
    for side in (-1,1):
        for j in range(6):
            x=-5.21+j*2.08
            if side<0 or x<3.4:
                box("Lower side panel",(x,side*2.15,1.88),(2.13,.22,1.69),teal,group,p,.074)
                box("Window", (x,side*2.16,4.46),(1.86,.09,2.83),window,group,p,.09)
            box("Window support",(x-1,side*2.15,4.45),(.17,.24,3.27),ivory,group,p,.043)
        box("Polished beltline",(0,side*2.17,2.76),(12.8,.105,.14),chrome,group,p,.028)
        for x in (-4.3,4.26):
            wheel=ball("Transit tire",(x,side*2.1,.79),(.83,.33,.84),tire,group,p)
            ball("Wheel rim",(x,side*2.42,.79),(.46,.069,.46),chrome,group,p)
    for sign in (-1,1):
        box("Bus bumper",(sign*6.42,0,.92),(.32,4.26,.38),chrome,group,p,.12)
        box("Bus end lower",(sign*6.29,0,1.98),(.22,4.29,1.87),teal,group,p,.11)
        box("Bus end glass",(sign*6.29,0,4.42),(.12,4.18,2.75),window,group,p,.075)
        for yy in (-1.38,1.38):
            box("Head or tail lamp",(sign*6.48,yy,1.82),(.15,.47,.34),shine,group,p,.069)
    for x in (-3.04,.38,3.01):
        box("Upholstered seat",(x,.31,2.77),(1.33,1.40,.18),seat,group,p,.07)
        box("Seat back",(x-.66,.31,3.33),(.2,1.38,1.18),seat,group,p,.07)
    box("Entry stair",(4.83,2.18,.65),(2.26,.76,.23),chrome,group,p,.063)
    doors=[]
    for index,x in enumerate((4.58,5.72)):
        ob=empty("Transit / sliding door",group,p,(x,2.2,0))
        box("Door panel",(0,0,1.78),(1.1,.19,1.33),teal,group,ob,.08)
        box("Door glass",(0,0,4.23),(1.04,.108,3.1),window,group,ob,.066)
        for side in (-1,1):
            box("Door trim",(side*.55,0,3.47),(.10,.21,4.59),ivory,group,ob,.026)
        doors.append(ob)
    indicators=[]
    for sign in (-1,1):
        for yy in (-1.59,1.59):
            indicators.append(box("Flashing indicator",(sign*6.52,yy,2.23),(.13,.32,.25),amber,group,p,.056))
    font("Bus route","RIVERSIDE   02",(-2.25,2.26,2.18),.34,ivory,group,p,(math.pi/2,0,math.pi))
    bag=material("Props / blue canvas",(51,108,184),.77)
    box("Canvas backpack",(0,0,0),(.89,.53,1.04),bag,group,result["bag"],.14)
    box("Front pocket",(0,-.278,-.13),(.67,.13,.41),glass,group,result["bag"],.07)
    box("Zipper pull",(.19,-.353,.065),(.13,.045,.049),chrome,group,result["bag"],.014)
    for x in (-.26,.26):box("Backpack strap",(x,.267,.03),(.105,.127,.87),ink,group,result["bag"],.04)
    box("Ticket paper",(0,0,0),(.25,.067,.39),ivory,group,result["ticket"],.022)
    font("Printed ticket route","02",(0,-.041,0),.12,ink,group,result["ticket"])
    box("Phone case",(0,0,0),(.33,.081,.53),ink,group,result["phone"],.06)
    box("Phone display",(0,-.048,0),(.27,.024,.451),glass,group,result["phone"],.035)
    ball("Basketball",(0,0,0),(.27,.27,.27),material("Ball / orange rubber",(218,108,51),.75),group,result["ball"])
    for plane in range(3):
        for k in range(18):
            angle=k*math.tau/18
            xyz=(math.cos(angle)*.27,math.sin(angle)*.27,0)
            if plane==1:xyz=(xyz[0],0,xyz[1])
            if plane==2:xyz=(0,xyz[0],xyz[1])
            ball("Ball seam",xyz,(.017,.017,.014),ink,group,result["ball"])
    pink=material("Cupcake frosting",(243,143,159),.45)
    ball("Cupcake wrapper",(0,0,.05),(.173,.167,.12),metal,group,result["cake"])
    ball("Frosting",(0,0,.183),(.189,.175,.102),pink,group,result["cake"])
    ball("Cherry",(.025,.026,.285),(.054,.058,.063),material("Cherry",(159,49,71),.36),group,result["cake"])
    box("Plug housing",(0,0,0),(.35,.29,.26),amber,group,result["plug"],.055)
    return result,doors,indicators

def make_light(group,name,kind,location,color,power,target=None,size=8):
    light=bpy.data.lights.new(name,kind)
    light.color=rgb(color)
    light.energy=power
    if kind=="AREA":light.shape,light.size="DISK",size
    obj=object_(name,light,group)
    obj.location=location
    if target is not None:obj.rotation_euler=(Vector(target)-obj.location).to_track_quat("-Z","Y").to_euler()
    return obj

looks={
 "afternoon": (2.0,(255,203,146),.45,(181,211,251)),
 "blue hour": (.66,(157,188,251),.46,(174,203,255)),
 "memory": (1.67,(255,190,132),.48,(206,223,248)),
 "next day": (2.15,(255,233,207),.53,(185,230,255)),
}
def scene_options(scene,frames):
    scene.frame_start,scene.frame_end=1,frames
    scene.render.resolution_x,scene.render.resolution_y=1080,1920
    scene.render.resolution_percentage=100
    scene.render.fps=30
    scene.view_settings.view_transform="AgX"
    scene.render.engine="BLENDER_EEVEE_NEXT"
    scene.eevee.taa_render_samples=48

centers=[tuple(float(x) for x in box_data) for box_data in town["boxes"]]
def ray_clear(start,end, local):
    direction=end-start
    for x,y,z,sx,sy,sz in local:
        center=V((x,y,z))
        extent=V((sx,sy,sz))*.5
        first,last=0.0,.98
        for i in range(3):
            delta=direction[i]
            low,high=center[i]-extent[i],center[i]+extent[i]
            if abs(delta)<.00001:
                if not low<=start[i]<=high:
                    first,last=1,0
                    break
            else:
                a,b=(low-start[i])/delta,(high-start[i])/delta
                first,last=max(first,min(a,b)),min(last,max(a,b))
                if first>=last:break
        if first<last:return False
    return True

def lens_position(mark,samples):
    point,target,fov=V(mark[0]),V(mark[1]),mark[2]
    nearby=[v for v in centers if (V(v)-target).length<38 or max(v[3:])>45]
    forward=(point-target).normalized()
    side=forward.cross(Vector((0,0,1))).normalized()
    options=[point,point+side*2.6,point-side*2.6,point+Vector((0,0,2.5)),
       point+side*5.3+Vector((0,0,1.4)),point-side*5.3+Vector((0,0,1.4)),
       point+forward*3.2+Vector((0,0,2.6)),target+Vector((2,-10,14)),target+Vector((-10,-5,11))]
    best=-float("inf")
    elected=point
    for index,option in enumerate(options):
        if not ray_clear(option,target,nearby):continue
        line=(target-option).normalized()
        right=line.cross(Vector((0,0,1))).normalized()
        up=right.cross(line)
        gain=0
        count=0
        lens=math.tan(math.radians(fov*.5))
        for sample in samples:
            for role,state in sample.items():
                if role=="Driver":continue
                sample_point=V(state[0])+Vector((0,0,2.13))
                view=sample_point-option
                depth=view.dot(line)
                if depth<=1:
                    gain-=8
                    count+=1
                    continue
                width=depth*lens*.5625
                height=depth*lens
                gain+=2-max(0,(abs(view.dot(right))+.77)/width-.92)*5.5
                gain-=max(0,(abs(view.dot(up))+1.95)/height-.95)*3
                gain+=1.1 if ray_clear(option,sample_point,nearby) else -4.8
                count+=1
        score=gain/max(1,count)-index*.12
        if score>best:
            best,elected=score,option
    return elected,target,fov

def shot_groups(samples):
    groups=[]
    for row in samples:
        mark=row[4]
        if not groups or groups[-1][0]!=mark:
            groups.append((mark,[row]))
        else:groups[-1][1].append(row)
    return groups

def adapt_staging(id,row):
    frame,beat,actors,props,mark,look,on,door,hazards=row
    new=dict(actors)
    def relocate(role,x=None,z=None,direction=None):
        if role not in new:return
        state=list(new[role])
        position=state[0].copy()
        if x is not None:position[0]=x
        if z is not None:position[2]=z
        state[0]=position
        if direction:state[1]=direction
        new[role]=state
    if id=="last-bus":
        if beat in (5,6,7,8):
            relocate("Baker",z=-6.36,direction=[-1,0,-.28] if beat in (6,7) else None)
        if beat in (6,7):
            relocate("Sister",x=-25.45,z=-6.53,direction=[1,0,-.34])
        if beat==7:
            mark=[[-24.1,5.28,-15.2],[-24.18,2.5,-6.42],54]
        if beat in (16,17):relocate("Sister",x=24.14)
    elif beat in (10,11):
        relocate("Captain",x=40.62)
    return [frame,beat,new,props,mark,look,on,door,hazards]

def build_stage(scene,id):
    film=performance[id]
    stage_frames=math.ceil(film["finish"]*30)
    scene_options(scene,stage_frames)
    lights=collection("LIGHTING • Animated palette",scene.collection)
    rigs=collection("CAST • FK controls and expression shapes",scene.collection)
    props_group=collection("PROPS • Animated objects",scene.collection)
    cameras=collection("CAMERAS • Fixed portrait setups",scene.collection)
    roles={role:Rig(role,rigs) for role in film["roles"]}
    props,doors,indicators=create_props(props_group)
    sky=bpy.data.worlds.new("Riverside / procedural sky")
    scene.world=sky
    sky.use_nodes=True
    bg=sky.node_tree.nodes["Background"]
    sun=make_light(lights,"Directional key","SUN",(-15,-23,25),(255,225,174),2.3,(0,5,0))
    sun.data.angle=.14
    local_lights=[]
    if id=="last-bus":
        for x,y in ((-42,-9),(-23,-7),(2,-11),(25,-9)):
            local_lights.append(make_light(lights,"Street bounce","AREA",(x,y-4,10),(255,216,172),380,(x,y,2.1),9))
    else:
        for x,y in ((38,18),(58,18)):
            local_lights.append(make_light(lights,"Basketball floodlight","AREA",(x,y,9.5),(255,221,162),2700,(48,9,0),6))
        make_light(lights,"Park entrance lantern","AREA",(38,-7,8),(255,187,126),575,(39,-1,2),6)
    samples=[adapt_staging(id,row) for row in film["frames"]]
    for number,(mark,rows) in enumerate(shot_groups(samples),1):
        p,target,fov=lens_position(mark,[sample[2] for sample in rows[::max(1,len(rows)//5)]])
        data=bpy.data.cameras.new(f"{number:02} / {fov:g}° portrait")
        data.sensor_fit="VERTICAL"
        data.sensor_height=32
        data.lens=16/math.tan(math.radians(fov*.5))
        data.clip_end=360
        cam=object_("Portrait camera "+str(number),data,cameras)
        cam.location=p
        cam.rotation_euler=(target-p).to_track_quat("-Z","Y").to_euler()
        marker=scene.timeline_markers.new(f"{number:02} • Beat {int(rows[0][1]):02}",frame=int(rows[0][0]))
        marker.camera=cam
        if scene.camera is None:scene.camera=cam
    saved={}
    def key(obj,prop,frame,cut=False):
        value=tuple(getattr(obj,prop))
        k=(obj.name,prop)
        last=saved.get(k)
        if last is not None and (cut or last[0]+2<frame) and frame>last[0]+1 and last[1]!=value:
            setattr(obj,prop,last[1])
            obj.keyframe_insert(prop,frame=frame-1,group=obj.name)
            setattr(obj,prop,value)
        if last is None or last[1]!=value or cut:
            obj.keyframe_insert(prop,frame=frame,group=obj.name)
        saved[k]=(frame,value)
    old_look=old_light=previous_cam=None
    previous_roles={}
    for row in samples:
        frame,beat,actors,props_state,mark,look,on,door,hazards=row
        frame=int(frame)
        cut=previous_cam!=mark
        previous_cam=mark
        time=(frame-1)/30
        if look!=old_look:
            energy,key_color,sky_strength,sky_color=looks[look]
            if old_look is not None:
                for owner,path in ((sun.data,"energy"),(sun.data,"color"),(bg.inputs[0],"default_value"),(bg.inputs[1],"default_value")):
                    owner.keyframe_insert(path,frame=frame-1)
            sun.data.energy,sun.data.color=energy,rgb(key_color)
            bg.inputs[0].default_value,bg.inputs[1].default_value=(*rgb(sky_color),1),sky_strength
            sun.data.keyframe_insert("energy",frame=frame)
            sun.data.keyframe_insert("color",frame=frame)
            bg.inputs[0].keyframe_insert("default_value",frame=frame)
            bg.inputs[1].keyframe_insert("default_value",frame=frame)
            old_look=look
        if id=="park-lights" and old_light!=on:
            for fixture in local_lights:
                if old_light is not None:fixture.data.keyframe_insert("energy",frame=frame-1)
                fixture.data.energy=2700 if on else 0
                fixture.data.keyframe_insert("energy",frame=frame)
            old_light=on
        for name,rig in roles.items():
            mark_state=actors.get(name)
            rig.pose(mark_state,time,name in previous_roles and not cut)
            key(rig.root,"location",frame,cut)
            if mark_state:
                for joint in rig.joints:
                    if joint==rig.root:
                        key(joint,"rotation_euler",frame,cut)
                    elif joint in rig.eyes or joint in (rig.mouth,rig.teeth):
                        key(joint,"scale",frame,cut)
                    else:
                        key(joint,"rotation_euler",frame,cut)
                        if joint in rig.brows:key(joint,"location",frame,cut)
        for instruction in props_state.values():
            if instruction[0]!="transfer":continue
            _,a,b,u,hand_a,hand_b=instruction
            if not .02<u<.98:continue
            pa,pb=roles[a],roles[b]
            root_a,root_b=pa.root.location,pb.root.location
            if (root_a-root_b).length>3.6:continue
            midpoint=root_a.lerp(root_b,.5)
            midpoint.z+=(pa.scale+pb.scale)*1.38
            midpoint.y-=.14
            weight=math.sin(math.pi*u)**.54
            for performer,hand in ((pa,hand_a),(pb,hand_b)):
                reach(performer,hand,midpoint,weight)
                index=0 if hand=="LeftHand" else 1
                for joint in performer.arms[index]:key(joint,"rotation_euler",frame)
        previous_roles=actors
        for name,prop in props.items():
            instruction=props_state.get(name)
            prop.rotation_euler=(0,0,0)
            if not instruction:prop.location=(0,0,-105)
            elif instruction[0]=="place":
                prop.location=V(instruction[1])
                if name=="ball":prop.rotation_euler.x=time*2.5
            elif instruction[0]=="hand":
                role,hand=instruction[1:]
                prop.location=world_position(roles[role].hands[hand])
                prop.rotation_euler.z=roles[role].root.rotation_euler.z
            else:
                kind,a,b,fraction,handA,handB=instruction
                gripA=world_position(roles[a].hands[handA])
                gripB=world_position(roles[b].hands[handB])
                prop.location=gripA.lerp(gripB,fraction)
                if kind=="toss":prop.location.z+=math.sin(math.pi*fraction)*1.65
                prop.rotation_euler.z=roles[a if fraction<.5 else b].root.rotation_euler.z
            key(prop,"location",frame,cut)
            key(prop,"rotation_euler",frame,cut)
        if id=="last-bus":
            for i,ob in enumerate(doors):
                ob.location.x=(4.58 if i==0 else 5.72)+door*(-.92 if i==0 else .81)
                key(ob,"location",frame,cut)
            for ob in indicators:
                glow=1 if hazards and int(time*3.6)%2==0 else .08
                ob.scale=(1,1,glow)
                key(ob,"scale",frame)
    scene.frame_set(1)
    print(f"{id}: {stage_frames} frames, {len(scene.timeline_markers)} camera cuts",flush=True)
    return stage_frames

stage2=bpy.data.scenes.new("02 • Park Lights — Stage")
stage2.collection.children.link(town_group)
projects=[("last-bus","THE LAST BUS",base),("park-lights","THE NIGHT THE PARK WENT DARK",stage2)]
stages=[(id,title,scene,build_stage(scene,id)) for id,title,scene in projects]
for action in bpy.data.actions:
    for curve in action.fcurves:
        for key in curve.keyframe_points:key.interpolation="LINEAR"
        curve.update()

font_path=media/"DejaVuSans-Bold.ttf"
subtitle_font=bpy.data.fonts.load(str(font_path)) if font_path.is_file() else None
if subtitle_font:subtitle_font.pack()

def edit_scene(id,title,stage,frames):
    scene=bpy.data.scenes.new(title+" · EDIT")
    scene_options(scene,frames)
    scene.render.use_sequencer=True
    scene.render.image_settings.file_format="FFMPEG"
    scene.render.ffmpeg.format="MPEG4"
    scene.render.ffmpeg.codec="H264"
    scene.render.ffmpeg.audio_codec="AAC"
    scene.render.ffmpeg.constant_rate_factor="HIGH"
    scene.render.filepath=f"//renders/{id}"
    seq=scene.sequence_editor_create().sequences
    image=seq.new_scene("01 • Animated portrait stage",stage,channel=1,frame_start=1)
    image.scene_input="CAMERA"
    audio=seq.new_sound("02 • Mixed narration, score and effects",str(media/(id+"-mix.mp3")),channel=2,frame_start=1)
    audio.sound.pack()
    for number,beat in enumerate(timings[id]["cues"],1):
        marker=scene.timeline_markers.new(f"Beat {number:02}",frame=1+round(beat["start"]*30))
        for start,end,text in beat["captions"]:
            a,b=1+round(start*30),1+round(end*30)
            strip=seq.new_effect("Subtitle · "+text,"TEXT",channel=3,frame_start=a,frame_end=max(a+1,b))
            strip.text=text
            strip.blend_type="ALPHA_OVER"
            strip.font_size=57
            if subtitle_font:strip.font=subtitle_font
            else:strip.use_bold=True
            strip.color=(1,.909,.77,1)
            strip.use_shadow=True
            strip.use_outline=True
            strip.outline_color=(.012,.015,.024,1)
            strip.outline_width=.12
            strip.location=(.5,.133)
            strip.wrap_width=.85
            strip.align_x="CENTER"
    scene.frame_set(1)
    return scene
edits=[edit_scene(*record) for record in stages]
if bpy.context.window:
    bpy.context.window.scene=edits[0]
    for area in bpy.context.window.screen.areas:
        if area.type=="VIEW_3D":
            area.type="SEQUENCE_EDITOR"
            area.spaces.active.view_type="PREVIEW"
bpy.ops.wm.save_as_mainfile(filepath=str(args.output))
if args.sample:
    for (id,title,stage,length),edit,beat in zip(stages,edits,(7,17)):
        frame=round(timings[id]["cues"][beat-1]["start"]*30)+38
        for render_scene in (stage,edit):
            render_scene.render.resolution_percentage=34
            render_scene.eevee.taa_render_samples=10
            render_scene.render.image_settings.file_format="PNG"
        if bpy.context.window:bpy.context.window.scene=edit
        edit.frame_set(frame)
        edit.render.filepath=str(args.output.with_name(id+"-sample.png"))
        bpy.ops.render.render(write_still=True)
