"""Produce narration and editable caption timing for the toilet-school short."""
import json,sys,textwrap,subprocess,wave,tempfile
from pathlib import Path
from array import array
import numpy as np
import onnxruntime as ort
from kokoro_onnx import Kokoro

lines=[
"The day a toilet bought my school, it charged me two coins to get out of the bathroom.",
"I assumed it was a prank. Then a tiny receipt slid out under the door. It said: new owner.",
"The toilet rolled into the courtyard singing its own theme song. The principal just handed over the keys.",
"It put coin slots on the doors and one on the drinking fountain. Then it charged the fountain for crying.",
"My friend Obesidy tried to pay with a bag of chips. The machine ate those too.",
"I started looking for whoever sold the school. Turns out the toilet had bought it with a lunch coupon.",
"I flipped the receipt over. In little letters it said: ownership expires when the lunch bell rings.",
"Perfect. Then we looked up. The toilet was unscrewing the clock from the wall.",
"It couldn't stop time, but it could hide the bell button. So it swallowed the button right in front of us.",
"Obesidy said it probably ate everything without reading the label. I thought about the coupon and got an idea.",
"We rolled the snack machine into the hall and taped my hand drawn sign to the top. Unlimited free coins.",
"The toilet abandoned its post so fast it left the tank lid behind. It jammed the whole machine into its bowl.",
"That was our chance. I climbed onto the bench and reached for the bell wires. They were way too high.",
"Then Obesidy noticed something on the floor. The lid from the toilet tank. It was made out of metal.",
"He slid it under the wires like a bridge. I pressed it up with the handle of a broom.",
"The bell rang. The toilet froze, spat out the machine, and printed a three foot receipt.",
"I thought it was a refund. It was the bill for all the chips Obesidy had tried to pay with.",
"He took one look at the total and pushed the toilet toward the staff restroom. He said to put it on their tab.",
"We got the school back. The principal put the keys on a lanyard so nobody could sell them again.",
"The toilet still goes to our school. We make it ask permission before it sings."
]
root=Path(__file__).resolve().parents[1]
opts=ort.SessionOptions(); opts.intra_op_num_threads=2; opts.inter_op_num_threads=1
model=Kokoro.from_session(ort.InferenceSession(sys.argv[1],sess_options=opts,providers=['CPUExecutionProvider']),sys.argv[2])
rate=24000
parts=[]
cues=[]; stem=0
for line in lines:
    vox,sr=model.create(line,voice="af_bella",speed=1.095,lang="en-us")
    assert sr==rate
    audible=np.flatnonzero(np.abs(vox)>.003)
    vox=vox[max(0,audible[0]-800):min(len(vox),audible[-1]+1200)]
    start=stem/rate
    spoken_end=(stem+len(vox))/rate
    vox=np.pad(vox,(0,round(.11*rate)))
    stem+=len(vox)
    pieces=textwrap.wrap(line,29,break_long_words=False)
    weights=[len(piece)+2*len(piece.split()) for piece in pieces]
    marks=[start+(spoken_end-start)*sum(weights[:j])/sum(weights) for j in range(len(pieces)+1)]
    cues.append({"start":round(start,3),"finish":round(stem/rate,3),"line":line,
        "captions":[[round(marks[j],3),round(marks[j+1],3),piece] for j,piece in enumerate(pieces)]})
    parts.append(vox)
track=np.concatenate(parts+[np.zeros(round(rate*.3))])
runtime=round(len(track)/rate,3)
assert 90<=runtime<=120,runtime
def tone(start,hz,duration,gain,decay):
    first=round(start*rate)
    t=np.arange(min(round(duration*rate),len(track)-first))/rate
    track[first:first+len(t)]+=gain*np.sin(t*hz*2*np.pi)*np.minimum(t*80,1)*np.exp(-decay*t)
for i,c in enumerate(cues):
    if i%2==0:
        for j,n in enumerate((220,293.66,329.63,440)):
            tone(c["start"]+.2+j*.31,n,1.3,.026,4)
for i,hz in ((0,285),(2,392),(11,143),(15,780),(16,440),(19,329.63)):
    start=cues[i]["start"]+.13
    tone(start,hz,1,.055,5)
with tempfile.TemporaryDirectory() as tmp:
    path=Path(tmp)/"mix.wav"
    with wave.open(str(path),"wb") as w:
        w.setparams((1,2,rate,0,"NONE","not compressed"))
        w.writeframes((np.clip(track,-.96,.96)*32767).astype("<i2").tobytes())
    subprocess.run(["ffmpeg","-v","error","-y","-i",str(path),"-af","loudnorm=I=-18:TP=-1.5:LRA=11","-ar","44100","-b:a","96k",str(root/"media/toilet-school-mix.mp3")],check=True)
p=root/"media/timings.json"
timings=json.loads(p.read_text())
timings["toilet-school"]={"finish":runtime,"cues":cues}
p.write_text(json.dumps(timings,indent=2)+"\n")
def stamp(t):
    x=round(t*1000)
    return f"{x//3600000:02}:{x//60000%60:02}:{x//1000%60:02},{x%1000:03}"
all_cues=[line for cue in cues for line in cue["captions"]]
(root/"media/toilet-school.srt").write_text("\n".join(f"{n}\n{stamp(a)} --> {stamp(b)}\n{line}\n" for n,(a,b,line) in enumerate(all_cues,1)))
print(runtime)
