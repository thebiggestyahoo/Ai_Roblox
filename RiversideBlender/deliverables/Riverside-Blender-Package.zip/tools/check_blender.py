"""Inspect the saved file and optionally render both edit timelines."""
import math
from pathlib import Path
import sys
import bpy

root=Path(__file__).resolve().parents[1]
edits=[scene for scene in bpy.data.scenes if scene.name.endswith("EDIT")]
assert len(edits)==2
for edit in edits:
    items=list(edit.sequence_editor.sequences)
    audio=next(strip for strip in items if strip.type=="SOUND")
    source=next(strip for strip in items if strip.type=="SCENE")
    lines=[strip for strip in items if strip.type=="TEXT"]
    assert (edit.render.resolution_x,edit.render.resolution_y,edit.render.fps)==(1080,1920,30)
    assert 90*30<=edit.frame_end<=120*30
    assert source.scene.frame_end==edit.frame_end
    assert source.frame_final_start==1 and source.frame_final_end>=edit.frame_end
    assert audio.sound.packed_file and audio.sound.packed_file.size>1000000
    assert all(strip.font.packed_file and strip.frame_final_start<strip.frame_final_end for strip in lines)
    assert len(lines)>50 and len(source.scene.timeline_markers)>20
    assert all(marker.camera for marker in source.scene.timeline_markers)
    assert any(obj.animation_data and obj.animation_data.action for obj in source.scene.objects if "MOTION" in obj.name)
    print(edit.name, edit.frame_end, len(source.scene.timeline_markers),len(lines),audio.sound.packed_file.size,flush=True)
    if "--renders" in sys.argv:
        park="PARK" in edit.name
        frame=next(m.frame for m in edit.timeline_markers if m.name=="Beat "+("17" if park else "07"))
        bpy.context.window.scene=edit
        edit.frame_set(frame+38)
        for scene in (edit,source.scene):
            scene.render.resolution_percentage=34
            scene.render.image_settings.file_format="PNG"
            scene.eevee.taa_render_samples=12
        edit.render.filepath=str(root/"deliverables"/("park-lights-sample.png" if park else "last-bus-sample.png"))
        bpy.ops.render.render(write_still=True)
