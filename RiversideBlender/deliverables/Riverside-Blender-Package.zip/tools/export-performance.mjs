import {readFileSync, writeFileSync} from "node:fs";
import {pathToFileURL} from "node:url";
import {resolve} from "node:path";
const [modules, source, destination]=process.argv.slice(2);
const {LuauState}=await import(pathToFileURL(resolve(modules,"luau-web/src/index.js")));
const story=readFileSync(resolve(source,"src/StoryData.luau"),"utf8");
const timing=readFileSync(resolve(source,"src/NarrationTiming.luau"),"utf8");
const engine=await LuauState.createAsync();
const run=engine.loadstring(`
local vector={}
local function V(x,y,z) return setmetatable({x=x,y=y,z=z},vector) end
vector.__add=function(a,b) return V(a.x+b.x,a.y+b.y,a.z+b.z) end
vector.__sub=function(a,b) return V(a.x-b.x,a.y-b.y,a.z-b.z) end
vector.__mul=function(a,b) return V(a.x*b,a.y*b,a.z*b) end
vector.__unm=function(a) return a*-1 end
vector.__index=vector
function vector:Lerp(b,t) return self+(b-self)*t end
local Vector3={new=V}
local Story=(function()
${story}
end)()
local Timing=(function()
${timing}
end)()
local function vec(v) return {v.x,v.y,v.z} end
local function encode(value)
	local kind=type(value)
	if kind=="number" then return string.format("%.5f",value) end
	if kind=="boolean" then return tostring(value) end
	if kind=="string" then return string.format("%q",value) end
	local strings={}
	if #value>0 then
		for _,element in ipairs(value) do table.insert(strings,encode(element)) end
		return "["..table.concat(strings,",").."]"
	end
	for k,v in value do table.insert(strings,encode(k)..":"..encode(v)) end
	return "{"..table.concat(strings,",").."}"
end
local c={}
function c:actor(role,p,dir,pose,mode,speed)
	self.actors[role]={vec(p),vec(dir),pose,mode or "",speed or 0}
end
function c:path(role,a,b,t,start,finish,mode,pose,endFace)
	local u=math.clamp((t-start)/(finish-start),0,1)
	local ramp=.14
	local progress,velocity=u-ramp/2,1
	if u<ramp then progress,velocity=u*u/(2*ramp),u/ramp
	elseif u>1-ramp then progress,velocity=1-ramp-(1-u)^2/(2*ramp),(1-u)/ramp end
	local dir=b-a
	local speed=math.sqrt(dir.x^2+dir.y^2+dir.z^2)*velocity/((1-ramp)*(finish-start)*self.duration)
	self:actor(role,a:Lerp(b,progress/(1-ramp)),speed>.06 and dir or endFace or dir,pose,speed>.06 and mode or nil,speed)
end
function c:prop(name,p) self.props[name]={"place",vec(p)} end
function c:hand(name,role,hand) self.props[name]={"hand",role,hand or "RightHand"} end
function c:transfer(name,a,b,u,hand,to) self.props[name]={"transfer",a,b,u,hand or "RightHand",to or hand or "RightHand"} end
function c:toss(name,a,b,u,hand,to) self.props[name]={"toss",a,b,u,hand or "RightHand",to or hand or "RightHand"} end
function c:shot(p,t,fov) self.camera={vec(p),vec(t),fov} end
function c:tone(look) self.look=look end
function c:lights(on) self.lampState=on end
function c:busState(door,hazards) self.door,self.hazards=door,hazards end
local output={}
for id,short in Story do
	local clock=Timing[id]
	local frames={}
	local beat=1
	local function sample(t,index)
		while beat<#clock.cues and t>=clock.cues[beat][2] do beat+=1 end
		local cue=clock.cues[beat]
		c.actors,c.props,c.look,c.lampState,c.door,c.hazards={},{},short.grade,short.grade=="afternoon",0,false
		c.duration=cue[2]-cue[1]
		short.scenes[beat](c,math.clamp((t-cue[1])/c.duration,0,1))
		frames[#frames+1]={index,beat,c.actors,c.props,c.camera,c.look,c.lampState,c.door,c.hazards}
	end
	local endFrame=math.ceil(clock.finish*30)
	for i=1,endFrame,2 do sample((i-1)/30,i) end
	if endFrame%2==0 then sample((endFrame-1)/30,endFrame) end
	output[id]={frames=frames,roles=short.roles,finish=clock.finish}
end
return encode(output)
`,"Blender performance export",true);
const [output]=await run();
const parsed=JSON.parse(output);
for(const [id,film] of Object.entries(parsed)) console.log(id,film.frames.length,"editable performance samples",film.finish);
writeFileSync(destination,output);
engine.destroy();
