"""Choreography for The Toilet That Bought the School."""
import math


def make_toilet_film(timing):
    frames=[]
    n=0
    def clip(u):return max(0,min(1,u))
    def smooth(u):
        u=clip(u)
        return u*u*(3-2*u)
    def P(x,z,h=0.08):return [x,h,z]
    def between(a,b,u):return [x+(y-x)*u for x,y in zip(a,b)]
    def act(role,x,z,direction=(0,0,-1),h=.10,**pose):
        actors[role]=[P(x,z,h),list(direction),pose,"",0]
    def walk(role,a,b,u,last=.85,**pose):
        t=smooth(u/last)
        d=[b[i]-a[i] for i in range(3)]
        speed=math.hypot(d[0],d[2])*6*clip(u/last)*(1-clip(u/last))/(last*duration)
        actors[role]=[between(a,b,t),d,pose,"run" if speed>5 else "walk",speed]
    def put(key,x,z,h=.08):props[key]=["place",P(x,z,h)]
    def held(key,role,hand="RightHand"):props[key]=["hand",role,hand]
    near=((151,5.3,-11),(161,2.85,1),57)
    reverse=((173,6.6,-11),(162,2.8,1),57)
    hall=((152,6.8,12.8),(162,3.06,23.8),57)
    hall_reverse=((173,6.12,14),(162,3.07,24.6),58)
    bench=((155,7.3,17),(162.7,3.9,26),56)
    end=((172,6.8,-9.9),(162,2.95,.1),57)
    tags={0:near,1:reverse,2:((158,5.8,-14.2),(162.6,2.7,.2),59),3:reverse,4:near,5:reverse,6:near,
        7:hall,8:hall_reverse,9:hall,10:hall_reverse,11:hall,12:bench,13:hall_reverse,
        14:bench,15:hall_reverse,16:hall,17:hall_reverse,18:near,19:end}
    for frame in range(1,math.ceil(timing["finish"]*30)+1,2):
        time=(frame-1)/30
        while n<len(timing["cues"])-1 and time>=timing["cues"][n]["finish"]:n+=1
        cue=timing["cues"][n]
        duration=cue["finish"]-cue["start"]
        u=clip((time-cue["start"])/duration)
        actors,props={},{}
        camera=list(tags[n])
        if n<=6:
            put("toilet",162.9,1,.12+.18*abs(math.sin(u*8)))
            act("Verity",158.6,-1.2,(.77,0,.65),worry=.6 if n<5 else .2, right=25, pitch=5)
            if n>=3:act("Obesidy",166.8,-.75,(-.83,0,.5),smile=.35,surprise=.45 if n==4 else 0)
            if n==0:
                put("gate",161.7,1.9)
                act("Verity",158.7,-.5,(.93,0,.41),right=52,worry=.81)
            elif n==1:
                put("receipt",161.9-2.37*smooth(u),-.25,.23)
                if u>.72:held("receipt","Verity")
            elif n==2:
                walk("Principal",P(169.9,-.3),P(166.1,.6),u,right=65)
                held("key","Principal")
                act("Verity",158.6,-1.2,(.38,0,-.9),surprise=.83,pitch=-6,yaw=20,right=35)
                put("toilet",162.0+2.4*smooth(u),1,.23+.18*abs(math.sin(u*19)))
            elif n==3:
                put("gate",161.9,1.85)
                put("slot",163.6,-.64,2.36)
            elif n==4:
                put("machine",163.6,2.7)
                act("Obesidy",166.9,-.62,(-.9,0,.4),right=53,surprise=.82)
                if u<.59:held("chips","Obesidy")
                else:put("chips",165.9-2.0*smooth((u-.59)*3),-.1+2.1*smooth((u-.59)*3),1.92)
            elif n in (5,6):held("receipt","Verity")
        elif n<=17:
            put("toilet",163.9,25.1,.13)
            put("bench",160.6,25.3)
            act("Verity",158.5,22.5,(.67,0,.77),worry=.45)
            act("Obesidy",167.9,22.4,(-.72,0,.69),surprise=.45)
            if n==7:
                put("clock",163.5,26.46,5.6-3.2*smooth(u))
                put("toilet",163.9,25.1,.12+.4*abs(math.sin(u*10)))
            if n==8:
                put("button",163.9,24.5,4.7-2.95*smooth(u))
            if n==9:
                held("receipt","Verity")
                act("Verity",158.5,22.5,(.67,0,.77),pitch=12,right=65,worry=.25,smile=.65*smooth(u))
            if n==10:
                put("machine",167.7-4.6*smooth(u),26.6)
                put("free-sign",167.7-4.6*smooth(u),26.52,4.52)
            if n==11:
                put("lid",164.8,24.3,.30)
                put("machine",163.1,26.5-1.32*smooth(u),0)
                if u>.58:
                    put("machine",163.1,25.18,1.15+4.8*smooth((u-.58)*2.5))
                    if u>.89:props.pop("machine")
                put("toilet",164-1.66*smooth(u),25.1,.12+.3*abs(math.sin(u*21)))
            if n in (12,13,14,15):
                put("wire",161.32,26.2,5.46)
                if n==12:
                    walk("Verity",P(158.5,22.5),P(160.62,25.32,1.28),u,.52,right=133,left=105)
                    put("lid",164.8,24.3,.30)
                elif n==13:
                    act("Verity",160.62,25.32,(.14,0,1),h=1.28,right=129,left=59,worry=.34)
                    walk("Obesidy",P(167.9,22.4),P(164.8,23.9),u,right=53,lean=17)
                    if u<.82:put("lid",164.8,24.3,.30)
                    else:held("lid","Obesidy")
                elif n==14:
                    act("Verity",160.62,25.32,(.14,0,1),h=1.28,right=69+55*smooth(u),left=52)
                    put("lid",161.4,26.12,1.4+4.03*smooth(u))
                    held("broom","Verity")
                else:
                    put("lid",161.4,26.12,5.43)
                    put("machine",164.2+3.2*smooth(u),25.25,1.3*(1-u))
                    put("receipt",163.9,23.8-1.1*smooth(u),.18)
                    act("Verity",160.62,25.32,(.26,0,1),h=1.28,smile=.85,left=56,right=75)
            if n==16:held("receipt","Verity")
            if n==17:
                walk("Obesidy",P(165.9,23.7),P(172.4,28.9),u,right=62)
                put("toilet",166.4+6*smooth(u),24.5+4.4*smooth(u))
        else:
            act("Verity",158.8,-.99,(.68,0,.72),smile=.86,right=34)
            act("Obesidy",166.7,-.63,(-.81,0,.56),smile=.71)
            act("Principal",163.7,2.45,(0,0,-1),smile=.78,right=61)
            held("key","Principal")
            if n==19:
                put("toilet",162.6,-.29,.12+.19*abs(math.sin(u*12)))
                act("Verity",158.65,-.7,(.89,0,.46),smile=.91,right=61*smooth(u))
        frames.append([frame,n+1,actors,props,camera,"afternoon" if n<7 or n>17 else "memory",True,0,False])
    return {"frames":frames,"roles":["Verity","Obesidy","Principal"],"finish":timing["finish"]}
